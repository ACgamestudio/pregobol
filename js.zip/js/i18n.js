/* =======================================================================
   PREGOBOL — i18n
   The game shipped in Portuguese. The UI language is now data, not markup:
   every label lives here and is stamped into the DOM on boot by aplicarIdioma().
   English is the default (spec §14); Portuguese is kept so nothing was lost.
   ======================================================================= */
const IDIOMAS = {

en: {
  /* --- opening / menu --- */
  start: '▶ START', startNote: 'Tap to begin — with sound, fullscreen',
  loading: 'loading intro…', skip: 'Skip ⏭',
  tagline: 'RESPECT · FOCUS · FUN',
  play: 'PLAY', playSub: 'quick match',
  twoPlayers: '2 PLAYERS', twoPlayersSub: 'same device',
  arcade: 'ARCADE', arcadeSub: 'unlock the fields',
  tournament: 'TOURNAMENT', tournamentSub: 'four rounds',
  challenges: 'CHALLENGES', challengesSub: 'physics puzzles',
  fieldSelect: 'FIELD SELECT', fieldSelectSub: 'pick the pitch',
  capSelect: 'CAP SELECT', capSelectSub: 'pick your cap',
  settings: 'SETTINGS', ai: 'AI', sound: 'SOUND',
  language: 'LANGUAGE', languageSub: 'português',
  online: 'ONLINE',
  onlineSub: 'play a friend on another device',
  soClose: 'OOOOH! SO CLOSE', track: 'TRACK',
  yourTeam: 'YOUR TEAM', nextOpponent: 'NEXT OPPONENT',
  opponent: 'OPPONENT', opponentPicking: 'opponent is picking a team…',
  opponentPicked: 'opponent:', teamTaken: 'your opponent took that team — pick another',
  youPickField: 'you pick the field', hostPickingField: 'the room owner is picking the field…',
  waitOpponentTeam: 'waiting for your opponent to pick a team…',
  aimGuide: 'AIM GUIDE', aimOn: 'on', aimOff: 'off — harder',
  worldTeams: 'WORLD TEAMS', brTeams: 'BRAZIL TEAMS',
  introCard: 'INTRO', introOn: 'on', introOff: 'skip to menu',
  chargeEarned: 'special charge',
  howCharges: 'CHARGES: score off a bank shot, a nail or a double rebound (+1 to +2). A golden nail gives +2 on contact.',
  createRoom: 'CREATE ROOM', joinRoom: 'JOIN ROOM', findMatch: 'FIND MATCH',
  roomCode: 'ROOM CODE', enterCode: 'type the 4 letters',
  waitingOpponent: 'waiting for opponent…', searching: 'looking for a match…',
  opponentTurn: "opponent's turn", yourTurn: 'YOUR TURN',
  opponentLeft: 'the opponent left the match', connecting: 'connecting…',
  netFail: 'could not connect', roomGone: 'room not found or already full',
  roomMissing: 'this room does not exist (closed, or wrong code)', roomFull: 'this room already has two players',
  hostAway: 'the room owner needs to have the game open', sendWhatsApp: '📲 SEND ON WHATSAPP',
  invited: 'you were invited! tap JOIN', resumed: 'your room is still open — waiting for your friend',
  comeBack: 'sent? come back here and wait',
  joinedWaitHost: s => `joined ✓ — waiting for the room owner to come back to the game${s ? ` (last seen ${s}s ago)` : ''}`,
  friendJoined: 'your friend joined ✓ — connecting…',
  friendJoinedWait: 'your friend joined ✓ — waiting for their phone to connect…',
  selfReconnecting: 'your friend joined ✓ — reconnecting you…',
  joinedWaiting: 'you are in! waiting for the room owner to come back to the game…',
  inviteMsg: c => `Let's play Pregobol! Tap the link and hit JOIN (room ${c}):`,
  holdToTalk: 'hold 🎙️ to talk', micDenied: 'microphone blocked — allow it in the browser',
  micUnsupported: 'this browser cannot record audio', voiceSent: 'voice message sent',
  voiceFail: 'voice message not sent', voiceFrom: '🎙️ opponent',
  shareCode: 'send this code to your friend', soon: 'coming soon',
  on: 'On', off: 'Off',

  /* --- bars and buttons --- */
  menu: '☰ Menu', soundOn: '🔊 Sound', soundOff: '🔇 Muted', newMatch: '↺ New match',
  hint: 'Drag back from the cap and release — a first-touch goal counts.',
  back: 'back to menu', locked: 'LOCKED',

  /* --- match HUD --- */
  player1: 'PLAYER 1', player2: 'PLAYER 2',
  turn: 'Turn', yourTurn: 'YOUR TURN', aim: 'AIM', power: 'POWER', shoot: 'SHOOT!',
  scores: 'valid goal!', thinking: 'AI thinking…', over: 'Full time',

  /* --- goals (§5) --- */
  goal: 'GOOOOOAL!',
  goalCries: ['GOAL!', 'WHAT A SHOT!', 'PERFECT!', 'UNBELIEVABLE!',
              'WHAT A GOAL!', 'TOP CORNER!', 'THAT WAS CLEAN!'],
  goalFor: n => `Point for ${n}`,

  /* --- combos (§9) --- */
  bankShot: 'BANK SHOT!', nailShot: 'OFF THE NAIL!', doubleRebound: 'DOUBLE REBOUND!',
  tripleRebound: 'TRIPLE REBOUND!', chainRebound: 'CHAIN REBOUND!',
  longShot: 'LONG SHOT!', perfectAngle: 'PERFECT ANGLE!', insaneRebound: 'INSANE REBOUND!',

  /* --- special shots (§6) --- */
  powerShot: 'POWER SHOT', precisionShot: 'PRECISION SHOT',
  curveShot: 'CURVE SHOT', bounceShot: 'BOUNCE SHOT',
  armed: 'ARMED', charges: 'charges', noCharges: 'No charges yet',
  earnedCharge: 'SPECIAL SHOT EARNED',

  /* --- results --- */
  youWin: 'YOU WIN!', youLose: 'YOU LOSE', champion: 'CHAMPION!',
  greatGame: 'GREAT GAME!', tryAgain: 'TRY AGAIN', nextMatch: 'NEXT MATCH',
  matchComplete: 'MATCH COMPLETE',
  goals: 'GOALS', shots: 'SHOTS', accuracy: 'ACCURACY',
  rebounds: 'REBOUNDS', powerShots: 'POWER SHOTS',

  /* --- unlocks (§11) --- */
  newField: 'NEW FIELD UNLOCKED!', newCap: 'NEW CAP UNLOCKED!',
  newChallenge: 'NEW CHALLENGE UNLOCKED!',

  /* --- modes --- */
  qualifier: 'QUALIFIER', quarterFinal: 'QUARTER FINAL',
  semiFinal: 'SEMI FINAL', final: 'FINAL', theFinal: 'THE FINAL',
  round: n => `Round ${n}`, stage: 'STAGE',
  challengeComplete: 'CHALLENGE COMPLETE!', challengeFailed: 'CHALLENGE FAILED',
  attemptsLeft: n => `${n} shot${n === 1 ? '' : 's'} left`,
  holeIn: 'IN THE HOLE! Turn lost.',
  rotate: 'Rotate your phone', rotateSub: 'PREGOBOL plays in landscape',
  easy: 'EASY', normal: 'NORMAL', hard: 'HARD', insane: 'INSANE'
},

pt: {
  start: '▶ Iniciar', startNote: 'Toque para começar — com som e em tela cheia',
  loading: 'carregando abertura…', skip: 'Pular ⏭',
  tagline: 'RESPEITO · FOCO · DIVERSÃO',
  play: 'JOGAR', playSub: 'partida rápida',
  twoPlayers: '2 JOGADORES', twoPlayersSub: 'mesmo aparelho',
  arcade: 'ARCADE', arcadeSub: 'libere os campos',
  tournament: 'TORNEIO', tournamentSub: 'quatro rodadas',
  challenges: 'DESAFIOS', challengesSub: 'quebra-cabeças',
  fieldSelect: 'CAMPO', fieldSelectSub: 'escolha a mesa',
  capSelect: 'TAMPINHA', capSelectSub: 'escolha a sua',
  settings: 'AJUSTES', ai: 'IA', sound: 'SOM',
  language: 'IDIOMA', languageSub: 'english',
  online: 'ONLINE',
  onlineSub: 'jogue com um amigo em outro aparelho',
  soClose: 'UUUH! QUASE!', track: 'MÚSICA',
  yourTeam: 'SEU TIME', nextOpponent: 'PRÓXIMO ADVERSÁRIO',
  opponent: 'ADVERSÁRIO', opponentPicking: 'adversário escolhendo o time…',
  opponentPicked: 'adversário:', teamTaken: 'o adversário pegou esse time — escolha outro',
  youPickField: 'você escolhe o campo', hostPickingField: 'o dono da sala está escolhendo o campo…',
  waitOpponentTeam: 'esperando o adversário escolher o time…',
  aimGuide: 'MIRA', aimOn: 'ligada', aimOff: 'desligada — difícil',
  worldTeams: 'TIMES DO MUNDO', brTeams: 'TIMES DO BRASIL',
  introCard: 'ABERTURA', introOn: 'ligada', introOff: 'ir direto ao menu',
  chargeEarned: 'carga especial',
  howCharges: 'CARGAS: faça gol de tabela, de prego ou com dois rebotes (+1 a +2). Prego dourado dá +2 só de encostar.',
  createRoom: 'CRIAR SALA', joinRoom: 'ENTRAR NA SALA', findMatch: 'PROCURAR PARTIDA',
  roomCode: 'CÓDIGO DA SALA', enterCode: 'digite as 4 letras',
  waitingOpponent: 'esperando o adversário…', searching: 'procurando partida…',
  opponentTurn: 'vez do adversário', yourTurn: 'SUA VEZ',
  opponentLeft: 'o adversário saiu da partida', connecting: 'conectando…',
  netFail: 'não foi possível conectar', roomGone: 'sala não encontrada ou já cheia',
  roomMissing: 'essa sala não existe (fechou ou o código está errado)', roomFull: 'essa sala já tem dois jogadores',
  hostAway: 'quem criou a sala precisa estar com o jogo aberto', sendWhatsApp: '📲 MANDAR NO WHATSAPP',
  invited: 'você foi convidado! aperte ENTRAR', resumed: 'sua sala continua aberta — esperando seu amigo',
  comeBack: 'mandou? volte pra cá e espere',
  joinedWaitHost: s => `entrou ✓ — esperando o dono da sala voltar pro jogo${s ? ` (visto há ${s}s)` : ''}`,
  friendJoined: 'seu amigo entrou ✓ — conectando…',
  friendJoinedWait: 'seu amigo entrou ✓ — esperando o celular dele conectar…',
  selfReconnecting: 'seu amigo entrou ✓ — reconectando você…',
  joinedWaiting: 'você entrou! esperando o dono da sala voltar pro jogo…',
  inviteMsg: c => `Bora jogar Pregobol! Toca no link e aperta ENTRAR (sala ${c}):`,
  holdToTalk: 'segure 🎙️ pra falar', micDenied: 'microfone bloqueado — libere no navegador',
  micUnsupported: 'este navegador não grava áudio', voiceSent: 'mensagem de voz enviada',
  voiceFail: 'mensagem de voz não enviada', voiceFrom: '🎙️ adversário',
  shareCode: 'mande este código pro seu amigo', soon: 'em breve',
  on: 'Ligado', off: 'Desligado',
  menu: '☰ Menu', soundOn: '🔊 Som', soundOff: '🔇 Sem som', newMatch: '↺ Nova partida',
  hint: 'Puxe a tampinha e solte — o gol vale já no primeiro toque.',
  back: 'voltar ao menu', locked: 'BLOQUEADO',
  player1: 'JOGADOR 1', player2: 'JOGADOR 2',
  turn: 'Vez de', yourTurn: 'SUA VEZ', aim: 'MIRA', power: 'FORÇA', shoot: 'CHUTA!',
  scores: 'vale gol!', thinking: 'IA pensando…', over: 'Fim',
  goal: 'GOOOOOL!',
  goalCries: ['GOL!', 'QUE CHUTE!', 'PERFEITO!', 'INACREDITÁVEL!',
              'QUE GOL!', 'NO ÂNGULO!', 'QUE LIMPEZA!'],
  goalFor: n => `Ponto do ${n}`,
  bankShot: 'DE TABELA!', nailShot: 'NO PREGO!', doubleRebound: 'DOIS QUIQUES!',
  tripleRebound: 'TRÊS QUIQUES!', chainRebound: 'QUIQUE EM SÉRIE!',
  longShot: 'DE LONGE!', perfectAngle: 'ÂNGULO PERFEITO!', insaneRebound: 'QUIQUE INSANO!',
  powerShot: 'CHUTE FORTE', precisionShot: 'CHUTE PRECISO',
  curveShot: 'CHUTE CURVO', bounceShot: 'CHUTE DE TABELA',
  armed: 'PRONTO', charges: 'cargas', noCharges: 'Sem cargas ainda',
  earnedCharge: 'CHUTE ESPECIAL GANHO',
  youWin: 'VOCÊ VENCEU!', youLose: 'VOCÊ PERDEU', champion: 'CAMPEÃO!',
  greatGame: 'BOA PARTIDA!', tryAgain: 'TENTE DE NOVO', nextMatch: 'PRÓXIMA',
  matchComplete: 'FIM DE PARTIDA',
  goals: 'GOLS', shots: 'CHUTES', accuracy: 'PRECISÃO',
  rebounds: 'QUIQUES', powerShots: 'ESPECIAIS',
  newField: 'NOVO CAMPO LIBERADO!', newCap: 'NOVA TAMPINHA LIBERADA!',
  newChallenge: 'NOVO DESAFIO LIBERADO!',
  qualifier: 'CLASSIFICATÓRIA', quarterFinal: 'QUARTAS',
  semiFinal: 'SEMIFINAL', final: 'FINAL', theFinal: 'A FINAL',
  round: n => `Rodada ${n}`, stage: 'FASE',
  challengeComplete: 'DESAFIO CUMPRIDO!', challengeFailed: 'DESAFIO PERDIDO',
  attemptsLeft: n => `${n} chute${n === 1 ? '' : 's'} restante${n === 1 ? '' : 's'}`,
  holeIn: 'CAIU NO BURACO! Perdeu a vez.',
  rotate: 'Gire o celular', rotateSub: 'O pregobol joga na horizontal',
  easy: 'FÁCIL', normal: 'MÉDIO', hard: 'FORTE', insane: 'INSANO'
}
};

let idioma = 'pt';   // default; the IDIOMA card in the menu flips it
/* t('key') → string; t('key', arg) → calls the function entries above. */
function t(k, arg) {
  const d = IDIOMAS[idioma] || IDIOMAS.en;
  const v = k in d ? d[k] : IDIOMAS.en[k];
  return typeof v === 'function' ? v(arg) : v;
}
const sorteio = a => a[Math.floor(Math.random() * a.length)];

/* Stamps every static label. Called on boot and whenever the language flips. */
function aplicarIdioma() {
  const set = (id, txt) => { const e = document.getElementById(id); if (e) e.textContent = txt; };
  const setHTML = (id, h) => { const e = document.getElementById(id); if (e) e.innerHTML = h; };
  document.documentElement.lang = idioma;

  set('btnIniciar', t('start'));
  set('notaAbertura', t('startNote'));
  set('carregando', t('loading'));
  set('btnPular', t('skip'));

  set('tagline', t('tagline'));
  /* the icon is part of the label: the menu is graffiti on a wall, and the
     pictogram is the tag next to the word */
  const card = (id, ico, txt, sub) =>
    setHTML(id, `<span class="ico">${ico}</span>${txt}<em>${sub}</em>`);
  card('cardPlay', '⚽', t('play'), t('playSub'));
  card('card2P', '👥', t('twoPlayers'), t('twoPlayersSub'));
  card('cardArcade', '🕹️', t('arcade'), t('arcadeSub'));
  card('cardTorneio', '🏆', t('tournament'), t('tournamentSub'));
  card('cardDesafios', '🎯', t('challenges'), t('challengesSub'));
  card('cardCampo', '🎨', t('fieldSelect'), t('fieldSelectSub'));
  card('cardTampa', '🔘', t('capSelect'), t('capSelectSub'));
  setHTML('cardAbertura', `<span class="ico">🎬</span>${t('introCard')}<em>${
    (Progresso.dados.abertura === false) ? t('introOff') : t('introOn')}</em>`);
  setHTML('cardMira', `<span class="ico">🎯</span>${t('aimGuide')}<em>${
    (typeof mostrarMira === 'undefined' || mostrarMira) ? t('aimOn') : t('aimOff')}</em>`);
  setHTML('cardNivel', `<span class="ico">🧠</span>${t('ai')}<em id="nivelEstado"></em>`);
  setHTML('cardSom', `<span class="ico">🔊</span>${t('sound')}<em id="somEstado"></em>`);
  setHTML('cardIdioma', `<span class="ico">🌎</span>${t('language')}<em>${t('languageSub')}</em>`);
  setHTML('cardOnline', `<span class="ico">🌐</span>${t('online')}<em>${t('onlineSub')}</em>`);

  set('rotName', t('rotate'));
  set('rotSub', t('rotateSub'));
  set('rotLabel', t('turn'));
  set('btnMenu', t('menu'));
  set('btnNovo', t('newMatch'));
  const bf = document.getElementById('btnFaixa');
  if (bf) bf.title = t('track');
  set('dicaBarra', t('hint'));
  set('voltarMenu2', t('back'));
  set('voltarMenu3', t('back'));
  set('voltarMenu4', t('back'));
  set('tituloCampo', t('fieldSelect'));
  set('tituloTampa', t('capSelect'));
  set('tituloDesafios', t('challenges'));
  set('tituloOnline', t('online'));
  set('rotCodigo', t('roomCode'));
  set('dicaCodigo', t('shareCode'));
  set('btnCriarSala', t('createRoom'));
  set('btnProcurar', t('findMatch'));
  set('btnEntrarSala', t('joinRoom'));
  set('voltarMenu5', t('back'));
  set('faixaCampeao', t('champion'));

  const bs = document.getElementById('btnSom');
  if (bs) bs.textContent = Som.ligado ? t('soundOn') : t('soundOff');
}
